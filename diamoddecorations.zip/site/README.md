# Diamond Decorations — sajt

Statički sajt, spreman za hostovanje (npr. GitHub Pages).

## Sadržaj
- `index.html` — glavna stranica
- `utisci.html` — stranica sa svim utiscima
- Sve slike, fontovi i skripte su ugrađeni u same HTML fajlove (self-contained).

## Hostovanje na GitHub Pages
1. Napravi novi repozitorijum na GitHub-u.
2. Ubaci `index.html` i `utisci.html` u koren repozitorijuma.
3. Idi na **Settings → Pages**.
4. Pod **Source** izaberi granu (npr. `main`) i folder `/root`, pa **Save**.
5. Sajt će za par minuta biti dostupan na `https://<korisnicko-ime>.github.io/<repo>/`.

Stranice su povezane (dugme „Vidi više utisaka" vodi na `utisci.html`, a nazad na `index.html`).
